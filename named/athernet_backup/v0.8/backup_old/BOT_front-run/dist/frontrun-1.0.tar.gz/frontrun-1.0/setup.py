from distutils.core import setup

setup(name="frontrun",version="1.0",py_modules=['core','Err','helpers','database','gui','interface','scanners','views'],)
